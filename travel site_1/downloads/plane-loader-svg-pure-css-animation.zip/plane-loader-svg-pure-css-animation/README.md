# Plane loader SVG pure CSS animation

A Pen created on CodePen.

Original URL: [https://codepen.io/webduke/pen/RydqXg](https://codepen.io/webduke/pen/RydqXg).

Created for https://www.idiliz.com